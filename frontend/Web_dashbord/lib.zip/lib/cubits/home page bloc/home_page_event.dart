abstract class HomePageEvent {}

class GetHomePageData extends HomePageEvent {}
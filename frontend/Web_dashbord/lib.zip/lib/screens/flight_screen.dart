import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:web_dashbord/assest/data%20and%20model/flight_model.dart';
import 'package:web_dashbord/assest/widgets/Custom%20appar.dart';
import 'package:web_dashbord/assest/widgets/left_slider.dart';
import 'package:web_dashbord/cubits/flight%20cubit/flight_list_cubit.dart';
import 'package:web_dashbord/screens/flight_return_screen.dart';

class FlightListPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // Padding(
          //   padding: const EdgeInsets.all(8.0),
          //   child: ElevatedButton(
          //     onPressed: () {
          //       final flightReturnListCubit = FlightReturnListCubit.get(context);
          //       flightReturnListCubit.cubitFlightReturnList();
          //       Navigator.push(
          //         context,
          //         MaterialPageRoute(
          //           builder: (context) => FlightReturnListPage(),
          //         ),
          //       );
          //     },
          //     child: Text('Show Return Flights',style: TextStyle(color: Color.fromARGB(255, 147, 221, 203)),),
          //   ),
          // ),
          // // الشريط العلوي
          CustomAppbar(
            title: "Flight",
            imageRoute: 'lib/assest/images/icons/plane (2).png',
            backBotton: false,
          ),
          // باقي الصفحة
          Expanded(
            child: Row(
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.2,
                  child: LeftSlider(),
                ),
                Expanded(
                  child: BlocBuilder<FlightListCubit, FlightListState>(
                    builder: (context, state) {
                      final flight = FlightListCubit.get(context).flights;

                      if (state is FlightListSuccess) {
                        return ListView.builder(
                          itemCount: flight.length,
                          itemBuilder: (context, index) {
                            return FlightsListItem(
                                flight: flight[index], index: index);
                          },
                        );
                      } else if (state is FlightListLoading) {
                        return Center(child: CircularProgressIndicator());
                      } else {
                        return Center(
                          child: Text('No data Available'),
                        );
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class FlightsListItem extends StatelessWidget {
  final FlightListModel flight;
  final int index;

  List<Color> airlineColors = [
    Colors.blue,
    Colors.red,
    Colors.green,
    Colors.yellow,
    Colors.orange,
  ];

  FlightsListItem({required this.flight, required this.index});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      child: Column(
        children: [
          Stack(
            children: [
              Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.asset(
                      'lib/assest/images/flight_plane.jpg', // Replace with the actual path to your airline logo image
                      width: 100,
                      height: 100,
                      fit: BoxFit.cover,
                    ),
                  ),
                  SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        flight.departureTime,
                        style: TextStyle(fontSize: 16, color: Colors.black),
                      ),
                      Text(
                        flight.arrivalTime,
                        style: TextStyle(fontSize: 16, color: Colors.black),
                      ),
                      Row(
                        children: [
                          Icon(
                            Icons.airplanemode_active,
                            color: airlineColors[index % airlineColors.length],
                          ),
                          SizedBox(width: 5),
                          Text(
                            flight.companyName,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '\$${flight.priceOfTickets}',
                  style: TextStyle(fontSize: 16, color: Colors.green),
                ),
                ElevatedButton(
                  onPressed: () {
                    // Navigate to flight details
                  },
                  child: Text(
                    'Show Details',
                    style: TextStyle(color: Color(0xff5FCEB6)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

Widget buildStarRating(int rating) {
  int fullStars = rating.floor();
  bool hasHalfStar = (rating - fullStars) >= 0.5;
  int emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
  double starSize = 20.0;

  List<Widget> stars = List.generate(
    fullStars,
    (index) => Icon(
      Icons.star,
      color: Colors.yellow,
      size: starSize,
    ),
  );

  if (hasHalfStar) {
    stars.add(
      Icon(
        Icons.star_half,
        color: Colors.yellow,
        size: starSize,
      ),
    );
  }

  stars.addAll(
    List.generate(
      emptyStars,
      (index) => Icon(
        Icons.star_border,
        color: Colors.yellow,
        size: starSize,
      ),
    ),
  );

  return Row(children: stars);
}

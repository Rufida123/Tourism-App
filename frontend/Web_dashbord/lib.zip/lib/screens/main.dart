import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:web_dashbord/assest/widgets/left_slider.dart';
import 'package:web_dashbord/cubits/add_services/add_flight/add_fight_web.dart';
import 'package:web_dashbord/cubits/add_services/add_flight/add_flight_cubit.dart';
import 'package:web_dashbord/cubits/add_services/add_hotel/add_hotel_cubit.dart';
import 'package:web_dashbord/cubits/add_services/add_hotel/add_hotel_web.dart';
import 'package:web_dashbord/cubits/add_services/add_hotel/add_room_cubit.dart';
import 'package:web_dashbord/cubits/add_services/add_hotel/add_room_web.dart';
import 'package:web_dashbord/cubits/add_services/add_trip/add_trip_cubit.dart';
import 'package:web_dashbord/cubits/add_services/add_trip/add_trip_web.dart';
import 'package:web_dashbord/cubits/flight%20cubit/flight_list_cubit.dart';
import 'package:web_dashbord/cubits/flight%20cubit/flight_list_web.dart';
import 'package:web_dashbord/cubits/flight%20cubit/flight_return_list_cubit.dart';
import 'package:web_dashbord/cubits/flight%20cubit/flight_return_list_web.dart';
import 'package:web_dashbord/cubits/home%20page%20bloc/home_page_bloc.dart';
import 'package:web_dashbord/cubits/hotel%20bloc/hotel_list_cubit.dart';
import 'package:web_dashbord/cubits/hotel%20bloc/hotel_list_web.dart';
import 'package:web_dashbord/cubits/offer_list/add_offer_cubit.dart';
import 'package:web_dashbord/cubits/offer_list/add_offer_web.dart';
import 'package:web_dashbord/cubits/offer_list/offer_list_cubit.dart';
import 'package:web_dashbord/cubits/offer_list/offer_list_web.dart';

import 'package:web_dashbord/cubits/reservations/reservation_cubit.dart';
import 'package:web_dashbord/cubits/reservations/reservations_web.dart';
import 'package:web_dashbord/cubits/trip/trip_web.dart';
import 'package:web_dashbord/cubits/users%20page%20cubit/users_cubit.dart';
import 'package:web_dashbord/cubits/users%20page%20cubit/users_web.dart';

import '../cubits/trip/trip_cubit.dart';
import 'log_in.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => AddOfferCubit(AddOfferWeb()),
      child: BlocProvider(
        create: (context) => AddRoomFeaturesCubit(AddRoomFeaturesWeb()),
        child: BlocProvider(
          create: (context) => AddRoomTypeCubit(AddRoomTypeWeb()),
          child: BlocProvider(
            create: (context) => AddRoomCubit(AddRoomWeb()),
            child: BlocProvider(
              create: (context) => AddHotelCubit(AddHotelWeb()),
              child: BlocProvider(
                create: (context) => AddFlightCubit(AddFlightWeb()),
                child: BlocProvider(
                  create: (context) => OfferListCubit(OfferListWeb()),
                  child: BlocProvider(
                      create: (context) => TripListCubit(TripListWeb()),
                      child: BlocProvider(
                          create: (context) => FlightListCubit(FlightListWeb()),
                          child: BlocProvider(
                            create: (context) =>
                                FlightReturnListCubit(FlightReturnListWeb()),
                            child: BlocProvider(
                              create: (BuildContext context) =>
                                  HotelListCubit(HotelListWeb()),
                              child: BlocProvider(
                                create: (context) =>
                                    AddTripActivityDetailsCubit(
                                        AddTripActivityDetailsWeb()),
                                child: BlocProvider(
                                  create: (context) => AddTripInDetailsCubit(
                                      AddTripInDetailsWeb()),
                                  child: BlocProvider(
                                    create: (context) => AddTripOutDetailsCubit(
                                        AddTripOutDetailsWeb()),
                                    child: BlocProvider(
                                      create: (context) => ReservationTripCubit(
                                          ReservationsTripWeb()),
                                      child: BlocProvider(
                                        create: (context) =>
                                            ReservationHotelCubit(
                                                ReservationsHotelWeb()),
                                        child: BlocProvider(
                                          create: (context) =>
                                              ReservationFlightCubit(
                                                  ReservationsFlightWeb()),
                                          child: BlocProvider(
                                            create: (context) =>
                                                UsersAddCashCubit(
                                                    UserAddCashWeb()),
                                            child: BlocProvider(
                                              create: (context) =>
                                                  UsersDetailsCubit(
                                                      UsersDetailsWeb()),
                                              child: BlocProvider(
                                                create: (context) =>
                                                    TripListCubit(
                                                        TripListWeb()),
                                                child: BlocProvider(
                                                    create: (BuildContext
                                                            context) =>
                                                        HomePageBloc(),
                                                    child: MultiProvider(
                                                        providers: [
                                                          // Add your ChangeNotifierProviders here
                                                          ChangeNotifierProvider<
                                                              DropDownReservationsState>(
                                                            create: (_) =>
                                                                DropDownReservationsState(),
                                                          ),
                                                          ChangeNotifierProvider<
                                                              DropDownAddServiceState>(
                                                            create: (_) =>
                                                                DropDownAddServiceState(),
                                                          ),
                                                          // ... Add other ChangeNotifierProviders as needed
                                                        ],
                                                        child: MaterialApp(
                                                          debugShowCheckedModeBanner:
                                                              false,
                                                          theme: ThemeData(
                                                            fontFamily:
                                                                "Alexandria",
                                                          ),
                                                          home: Log_in(),
                                                        ))),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ))),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

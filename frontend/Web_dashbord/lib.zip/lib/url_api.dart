const String localhost = "http://127.0.0.1:8000/api";
//auth
//const String login = "http://127.0.0.1:8000/api/admin/login_admin";
const String login = "http://127.0.0.1:8000/api/login_admin";
const String forgetPasswordEmailUrl = "http://127.0.0.1:8000/api/admin/user/password/email";
const String checkCodeUrl = "http://127.0.0.1:8000/api/user/password/code/check";
const String newpasswordurl = "http://127.0.0.1:8000/api/admin/user/password/reset";
const String usersCountUrl = "http://127.0.0.1:8000/api/getUsersCount";
const String departFlightUrl = "http://127.0.0.1:8000/api/departure";
const String returnFlightUrl = "http://127.0.0.1:8000/api/return";
const String HotelUrl = "http://127.0.0.1:8000/api/index";
const String tripUrl="http://127.0.0.1:8000/api/trip";
const String imageUrl = "http://127.0.0.1:8000";

const String baseUrl="http://127.0.0.1:8000/api";
class PushNotification {
  String? title;
  String? body;
  PushNotification({this.title, this.body});
}

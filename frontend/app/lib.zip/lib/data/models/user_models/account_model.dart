class AccountModel {
  final int id;
  final String firstName;
  final String emailVerifiedAt;
  final String lastName;
  final String email;
  final String? image;
  final String? wallet;
  final String? phone;
  final String createdAt;
  final String updatedAt;
  final String? photos;

  AccountModel({
    required this.id,
    required this.firstName,
    required this.emailVerifiedAt,
    required this.lastName,
    required this.email,
    this.image,
    this.wallet,
    this.phone,
    required this.createdAt,
    required this.updatedAt,
    this.photos,
  });

factory AccountModel.fromJson(Map<String, dynamic> json) {
    return AccountModel(
      id: json['id'],
      firstName: json['first_name'],
      emailVerifiedAt: json['email_verified_at'],
      lastName: json['last_name'],
      email: json['email'],
      image: json['image'],
      wallet: json['wallet'],
      phone: json['phone'],
      createdAt: json['created_at'],
      updatedAt: json['updated_at'],
      photos: json['photos'],
    );
  }
}

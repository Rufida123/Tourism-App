import 'package:app/pages/User/cubits/flights/flight_details_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

// Define a new StatefulWidget for the flights display page
class FlightDetailsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final myColor = Theme.of(context).primaryColor;
    return BlocBuilder<FlightDetailsCubit, FlightDetailsState>(
      builder: (context, state) {
        final flight = FlightDetailsCubit.get(context).flightdetails;

        return Scaffold(
          appBar: AppBar(
            title: Text('Flight Details'),
            backgroundColor: Color.fromARGB(255, 103, 194, 180),
          ),
          body: state is FlightDetailsSuccess && flight != null
              ? Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Card(
                    margin: EdgeInsets.only(bottom: 8.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 3,
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(16.0),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.3),
                                        spreadRadius: 5,
                                        blurRadius: 7,
                                        offset: Offset(0, 3),
                                      ),
                                    ],
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(16.0),
                                    child: Transform(
                                      alignment: Alignment.center,
                                      transform: Matrix4.skewY(-0.1),
                                      child: Image.asset(
                                        'assets/7xm.xyz667851.jpg',
                                        width: double.infinity,
                                        height: 300,
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(height: 20),
                                Text(
                                  'Departure Time: ${flight.departureTime}',
                                  style: TextStyle(fontSize: 16.0),
                                ),
                                SizedBox(height: 5),
                                Text(
                                  'Arrival Time: ${flight.arrivalTime}',
                                  style: TextStyle(fontSize: 16.0),
                                ),
                                SizedBox(height: 5),
                                Text(
                                  'Final Rating: ${flight.finalRating}',
                                  style: TextStyle(fontSize: 16.0),
                                ),
                                SizedBox(height: 20),
                                Center(
                                  child: ElevatedButton(
                                    onPressed: () {
                                      // int id=flight.id;
                                      // Navigator.push(
                                      //   context,
                                      //   MaterialPageRoute(builder: (context) => FlightsBookingPage(id:id)),
                                      // );
                                      // Handle booking action
                                    },
                                    child: Text(
                                      'Booking Flight',
                                      style: TextStyle(
                                          color: Color.fromARGB(
                                              255, 103, 194, 180)),
                                    ),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor:
                                          Colors.white, // White background
                                      side: BorderSide(
                                          color: Color.fromARGB(255, 103, 194,
                                              180)), // Border color
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              : SizedBox(),
        );
      },
    );
  }
}



// Define a flight card widget
// class FlightCard extends StatelessWidget {

//   @override
//   Widget build(BuildContext context) {
//     final myColor = Theme.of(context).primaryColor; 
//     // Get primary color from theme

//     return Card(
//       margin: EdgeInsets.only(bottom: 20.0),
//       child: Container(
//         decoration: BoxDecoration(
//           image: DecorationImage(
//             image: AssetImage("assets/7xm.xyz667851.jpg"), // Your background image
//             fit: BoxFit.cover,
//             colorFilter: ColorFilter.mode(
//               myColor.withOpacity(0.2), // Adjust opacity as needed
//               BlendMode.dstATop,
//             ),
//           ),
//         ),
//         child: Padding(
//           padding: const EdgeInsets.all(30.0), // Adjust the padding as needed
//           child: Column(
//             children: [
//               ListTile(
//                 leading: Icon(
//                   Icons.flight,
//                   size: 40.0,
//                   color: Color.fromARGB(255, 29, 77, 78),
//                 ), // Increase the size of the icon
//                 title: Text(
//                   'Flight Name',
//                   style: TextStyle(fontSize: 20.0), // Increase the font size of the title
//                 ),
//                 subtitle: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Text(
//                       'Departure Time: 08:00 AM', // Example departure time
//                       style: TextStyle(fontSize: 16.0), // Increase the font size of the departure time
//                     ),
//                     Text(
//                       'Arrival Time: 10:00 AM', // Example arrival time
//                       style: TextStyle(fontSize: 16.0), // Increase the font size of the arrival time
//                     ),
//                   ],
//                 ),
//               ),
//               SizedBox(height: 20), // Add some space between ListTile and the button
//               ElevatedButton(
//                 onPressed: () {
//                    Navigator.push(
//                                   context,
//                                   MaterialPageRoute(builder: (context) => FlightsBookingPage()),
//                                 );
//                   // Handle booking action
//                 },
//                 child: Text('Show details',style: TextStyle(color: Color.fromARGB(255, 103, 194, 180)),),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
